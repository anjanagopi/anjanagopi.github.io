# Anjana Gopi – Portfolio Website

A fast, dark, responsive portfolio built with plain HTML, CSS and a little JavaScript.
No installs, no build step, no paid services. Edit the files, push to GitHub, and the site updates.

## Folder structure

```
anjana-portfolio/
├── index.html              ← ALL your text content lives here (edit this most)
├── css/styles.css          ← colours, fonts, layout (colours are at the very top)
├── js/main.js              ← menu, scroll animations (rarely needs editing)
├── assets/
│   ├── Anjana_Gopi_Resume.pdf   ← the file the "Download Resume" button uses
│   ├── Anjana_Gopi_Resume.docx  ← editable copy (no DOB / home address)
│   ├── favicon.svg
├── .nojekyll
└── README.md
```

## 1. Run it on your computer (VS Code)

1. Install **VS Code** from https://code.visualstudio.com
2. In VS Code: **File → Open Folder…** and choose the `anjana-portfolio` folder.
3. Open the **Extensions** panel (square icon on the left), search for **Live Server** (by Ritwick Dey) and click **Install**.
4. Right-click `index.html` → **Open with Live Server**. Your site opens in the browser and refreshes every time you save.

(You can also just double-click `index.html` to open it, but Live Server is nicer.)

## 2. Put it on GitHub and publish it free (GitHub Pages)

### A. One-time setup
1. Go to https://github.com and sign in (your username from the resume: `anjanagopi`).
2. Click **+ → New repository**.
3. **Repository name:** `anjanagopi.github.io`
   (This special name gives you the clean address **https://anjanagopi.github.io**. If you use any other name, your link will be `https://anjanagopi.github.io/<repo-name>/`.)
4. Choose **Public**. Leave "Add a README" **unticked**. Click **Create repository**.

### B. Upload the files (no Git commands needed)
1. On the new empty repository page, click **uploading an existing file**.
2. Open the `anjana-portfolio` folder on your computer, select **everything inside it** (`index.html`, `css`, `js`, `assets`, `README.md`, `.nojekyll`) and drag it into the browser.
   Make sure `index.html` ends up at the top level of the repository, not inside another folder.
3. Scroll down, type a message like `Add portfolio`, and click **Commit changes**.

### C. Turn on the website
1. In the repository, click **Settings → Pages** (left menu).
2. Under **Build and deployment → Source**, choose **Deploy from a branch**.
3. Branch: **main**, folder: **/ (root)**, then click **Save**.
4. Wait 1–2 minutes and refresh. A box appears saying **Your site is live at https://anjanagopi.github.io**. That is the link you share.

## 3. How to edit it later

**Easiest (in the browser):**
1. Open your repository on GitHub, click a file such as `index.html`.
2. Click the **pencil icon** (Edit), make your change, click **Commit changes**.
3. Wait about a minute and refresh your site.

**In VS Code with Git (optional, when you're comfortable):**
```
git clone https://github.com/anjanagopi/anjanagopi.github.io.git
# edit files in VS Code, then:
git add .
git commit -m "Update portfolio"
git push
```

## 4. What to edit

| I want to…                         | Where                                                                 |
| ---------------------------------- | --------------------------------------------------------------------- |
| Change any text                    | `index.html` – each section has a comment banner like `ABOUT`         |
| Add GitHub / demo links to projects| `index.html` → find `GitHub: add link` and replace the whole `<span class="link-disabled">…</span>` with `<a class="btn btn-ghost" href="YOUR-URL" target="_blank" rel="noopener">GitHub</a>` |
| Add a new project                  | Copy an existing `<article class="project">…</article>` block         |
| Update the resume                  | Replace `assets/Anjana_Gopi_Resume.pdf` with a new PDF using the **same file name** |
| Change colours                     | Top of `css/styles.css` (the `:root` block)                           |
| Add your phone number              | Left out on purpose (see privacy note). Add it in the Contact section if you want. |

## 5. Before you share the link – checklist

- [ ] Add real **GitHub links** to projects (or leave the dashed "add link" tags out by deleting them).
- [ ] Open the live site on your phone and click every menu item, button and link.
- [ ] Confirm **Download Resume** downloads the file.

## Privacy note

The resume PDF on this site has your **date of birth and home address removed**. Your phone number is still on the PDF because it is in the header of your resume; delete it from `assets/Anjana_Gopi_Resume.docx`, re-export as PDF, and re-upload if you'd rather not publish it. Anything on a public site can be seen and copied by anyone.

## Notes on content

- Everything on the site comes from your resume. The skills list adds photography, video editing, content creation, communication, leadership and teamwork because you named them yourself.
- **MindBridge AI chatbot** is not in your resume, so it is not on the site. Send me its details (what it does, tech used, GitHub link) and I'll add it as a featured project.
- Fonts load from Google Fonts. If they can't load, the site falls back to system fonts and still looks good.
